library(testthat)
library(xlum)

test_check("xlum")
